package testing1;

public class User {
	static String username;
	static String password;
	static int status=0;
}
